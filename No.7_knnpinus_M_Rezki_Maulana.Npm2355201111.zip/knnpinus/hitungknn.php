<!DOCTYPE html>
<html lang="en">
<head>
  <title>Perhitungan - SIM AI KNN Pinus V.2025</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<div class="container mt-3">
  <h2>Perhitungan Algoritma K - Nearest Neighbourhood :</h2>
  <p>Berikut ini hasil perhitungan Jarak Euclidean :</p>    
  <?php include_once('koneksi.php');
    $id=mysqli_real_escape_string($koneksi,$_GET['id']);
    $sqlu="select * from input_data_uji where id='".$id."'";
    $qu=mysqli_query($koneksi,$sqlu);
    $ru=mysqli_fetch_array($qu);
    $lingkarbatanguji=$ru['lingkarbatang']; //ambil kecerahan uji dulu
    $tinggiuji=$ru['Kejenuhan']; //ambil kejenuhan ujinya
    $k=$ru['k']; //ambil nilai K / jumlah tetangga yang akan diperhitungkan 
    $sqlt="select * from input_data_training"; //persiapan sql untuk semua data training
    $qt=mysqli_query($koneksi,$sqlt);
    $rt=mysqli_fetch_array($qt);  //ambil semua rekordnya
    do {
        //hitung jaraknya
        $j=((($lingkarbatanguji-$rt['lingkarbatang'])**2)+(($tinggiuji-$rt['tinggi'])**2))**(1/2);
        $sqlp="insert into perhitungan (id,lingkarbatang,tinggi,jarak,kelas) values ('".$id."','".$rt['lingkarbatang']."','".$rt['tinggi']."','".$j."','".$rt['kelas']."')";
        $qp=mysqli_query($koneksi,$sqlp);
        if ($qp) echo "jarak ".@$n++." lingkarbatanguji : ".$lingkarbatanguji.
        "tinggiuji: ".$tinggiuji." lingkarbatang t: ".$rt['lingkarbatang']." tinggi t: ".$rt['tinggi']." jarak = ".$j." berhasil dihitung !<br>";
    }while($rt=mysqli_fetch_array($qt));
  ?>
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>Jarak</th>
        <th>Kelas</th>
      </tr>
    </thead>
    <tbody>
      <?php $sqltp="select * from perhitungan where id='".$id."' order by Jarak ASC";
      $qtp=mysqli_query($koneksi,$sqltp);
      $rtp=mysqli_fetch_array($qtp);$n=0;
      do { ?>  
      <tr>
        <td><?php echo $rtp['jarak'];?></td>
        <td><?php echo $rtp['kelas'];?></td>
      </tr>
      <?php 
      $sqlh="INSERT INTO `hasil`(`id`, `jarak`, `kelas`) VALUES ('".$id."','".$rtp['jarak']."','".$rtp['kelas']."')";
       $qh=mysqli_query($koneksi,$sqlh);
       $n++;
       if($n>=$K) break;
    }while($rtp=mysqli_fetch_array($qtp)); 
    $sqlkesimpulan="SELECT *,count(kelas) as jumlahtetangga FROM `hasil` GROUP by kelas;";
    $qkesimpulan=mysqli_query($koneksi,$sqlkesimpulan);
    $rkesimpulan=mysqli_fetch_array($qkesimpulan);
    do {
    $sqluh="update hasil set Jumlah=".$rkesimpulan['jumlahtetangga']." WHERE id='".$id."' and Kelas='".$rkesimpulan['kelas']."'";
    $quh=mysqli_query($koneksi,$sqluh);
    }while($rkesimpulan=mysqli_fetch_array($qkesimpulan));
    $sqlmaxh="select Kelas,max(jumlah) as jumlah from hasil where id='".$id."'";
    $qmaxh=mysqli_query($koneksi,$sqlmaxh);
    $rmaxh=mysqli_fetch_array($qmaxh);
    echo "Hasil prediksi Kelas Baru  = ".$rmaxh['kelas'];
    $sqluuji="UPDATE input_data_uji set kelas='".$rmaxh['kelas']."' WHERE id='".$id."'";
    $quuji=mysqli_query($koneksi,$sqluuji);
    ?>
    </tbody>
  </table>
  
</div>

</body>
</html>