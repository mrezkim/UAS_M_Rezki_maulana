<!DOCTYPE html>
<html lang="en">
<head>
  <title>SIM AI KNN Pinus V. 2025 </title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>

<!-- Carousel -->
<div id="demo" class="carousel slide" data-bs-ride="carousel">

  <!-- Indicators/dots -->
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#demo" data-bs-slide-to="0" class="active"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="1"></button>
    <button type="button" data-bs-target="#demo" data-bs-slide-to="2"></button>
  </div>
  
  <!-- The slideshow/carousel -->
<div class="carousel-inner text-center">
  <div class="carousel-item active">
    <img src="tabeldaftaruji.jpg" alt="Tabel Data Training" class="img-fluid mx-auto d-block" style="max-height: 500px; object-fit: contain; margin-bottom: 30px;">
  </div>
  <div class="carousel-item">
    <img src="tabeldatatraining.jpg" alt="Tabel Data Uji" class="img-fluid mx-auto d-block" style="max-height: 500px; object-fit: contain; margin-bottom: 30px;">
  </div>
</div>

  <!-- Left and right controls/icons -->
  <button class="carousel-control-prev" type="button" data-bs-target="#demo" data-bs-slide="prev">
    <span class="carousel-control-prev-icon"></span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#demo" data-bs-slide="next">
    <span class="carousel-control-next-icon"></span>
  </button>
</div>

<div class="gambarcircumference">
    <h4>Tabel Circumference (cm) vs Height of Pine Tree Species:</h4>
    <img src="tabelcircumference.jpg" alt="Atas" style="width:600px; margin-top: 10px; margin-bottom: 10px;">
    <p>Tabel circumference tersebut di dapatkan dari data mentah yang di hitung pada Excel</p>
</div>

<div>
    <p>SIM AI KNN Pinus V. 2025</p>
    <p>Dibuat untuk menyelesaikan tugas UAS Matkul kecerdasan buatan yang di ampuh oleh bapak HarryWitriyono</p>
    <p>Nama : M Rezki Maulana</p>
    <p>NPM  : 2355201111</p>
</div>

</body>
</html>