<?php
$host       = "localhost";
$username   = "root";
$password   = "";
$database   = "knnpinus";
$koneksi    = new mysqli($host, $username, $password, $database);
?>