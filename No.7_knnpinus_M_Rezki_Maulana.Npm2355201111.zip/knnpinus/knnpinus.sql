-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 18, 2025 at 12:59 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `knnpinus`
--

-- --------------------------------------------------------

--
-- Table structure for table `hasil`
--

CREATE TABLE `hasil` (
  `id` int(50) NOT NULL,
  `jarak` double(5,2) DEFAULT NULL,
  `kelas` varchar(15) DEFAULT NULL,
  `jumlah` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `input_data_training`
--

CREATE TABLE `input_data_training` (
  `id` int(100) NOT NULL,
  `lingkarbatang` varchar(100) NOT NULL,
  `tinggi` varchar(100) NOT NULL,
  `kelas` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `input_data_training`
--

INSERT INTO `input_data_training` (`id`, `lingkarbatang`, `tinggi`, `kelas`) VALUES
(11, '0.3', '7.21', '3'),
(12, '0.18', '5.12', '3'),
(13, '0.46', '8.83', '3'),
(14, '0.63', '12.08', '3'),
(15, '0.23', '5.81', '3'),
(16, '0.56', '13.5', '3'),
(17, '0.39', '10.9', '3'),
(18, '0.41', '6.79', '3'),
(19, '0.62', '10.66', '3'),
(20, '0.43', '10.5', '3'),
(21, '0.15', '2.67', '3'),
(22, '0.19', '20.34', '2'),
(23, '0.17', '19.72', '2'),
(24, '0.17', '19.8', '2'),
(25, '0.22', '23.7', '2'),
(26, '0.45', '32.51', '2'),
(27, '0.39', '26.23', '2'),
(28, '0.42', '32.51', '2'),
(29, '0.38', '29.18', '2'),
(30, '0.3', '26.1', '2'),
(31, '0.18', '21.51', '2');

-- --------------------------------------------------------

--
-- Table structure for table `input_data_uji`
--

CREATE TABLE `input_data_uji` (
  `id` int(100) NOT NULL,
  `lingkarbatang` varchar(100) DEFAULT NULL,
  `tinggi` varchar(100) DEFAULT NULL,
  `kelas` varchar(100) DEFAULT NULL,
  `k` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `input_data_uji`
--

INSERT INTO `input_data_uji` (`id`, `lingkarbatang`, `tinggi`, `kelas`, `k`) VALUES
(6, '0.2', '15.2', '3', 3);

-- --------------------------------------------------------

--
-- Table structure for table `kelas`
--

CREATE TABLE `kelas` (
  `id` int(11) NOT NULL,
  `kelas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kelas`
--

INSERT INTO `kelas` (`id`, `kelas`) VALUES
(2, 'White Pine'),
(3, 'Douglas Fir');

-- --------------------------------------------------------

--
-- Table structure for table `perhitungan`
--

CREATE TABLE `perhitungan` (
  `id` int(11) NOT NULL,
  `lingkarbatang` double(5,2) NOT NULL,
  `tinggi` double(5,2) NOT NULL,
  `jarak` double(5,2) NOT NULL,
  `kelas` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hasil`
--
ALTER TABLE `hasil`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `input_data_training`
--
ALTER TABLE `input_data_training`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `input_data_uji`
--
ALTER TABLE `input_data_uji`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `perhitungan`
--
ALTER TABLE `perhitungan`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hasil`
--
ALTER TABLE `hasil`
  MODIFY `id` int(50) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `input_data_training`
--
ALTER TABLE `input_data_training`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=32;

--
-- AUTO_INCREMENT for table `input_data_uji`
--
ALTER TABLE `input_data_uji`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `perhitungan`
--
ALTER TABLE `perhitungan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
